FactoryGirl.define do
  factory :answer do
    reference_to '1.1.2'
    pia
  end
end
