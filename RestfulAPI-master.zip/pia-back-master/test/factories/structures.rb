FactoryGirl.define do
  factory :structure do
    name 'Structure 1'
    sector_name 'Structure Sector Name 1'
    data '{"sections":[]}'
  end
end
