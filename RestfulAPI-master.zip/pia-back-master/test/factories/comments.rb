FactoryGirl.define do
  factory :comment do
    reference_to '1.1.2'
    pia
  end
end
