FactoryGirl.define do
  factory :measure do
    pia
  end
end
