require 'test_helper'

class StructureTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
