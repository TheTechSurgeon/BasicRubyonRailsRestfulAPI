require 'test_helper'

class PiaTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
