CarrierWave.configure do |config|
  config.root = Rails.root
end