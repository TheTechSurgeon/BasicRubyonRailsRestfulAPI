class MeasureSerializer < ActiveModel::Serializer
  attributes :id, :pia_id, :title, :content, :placeholder
end
